@extends('template_backend.home')

@section('content')

<h1>This is content</h1>
    
@endsection
