<?php



Route::get('/', function () {
    return view('home');
});

Route::resource('category','CategoryController');

Route::resource('tag','TagsController');

Route::resource('post','PostController');
